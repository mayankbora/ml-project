# Heroku_deploy
this repository include an ML model deployment 

here is the link of app : https://mlsalaryprediciton-api.herokuapp.com/
